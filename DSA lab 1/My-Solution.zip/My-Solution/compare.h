#include "storage.h"

// external function compare. returns value of type ORDER
extern ORDER compare (Job j1,Job j2);
