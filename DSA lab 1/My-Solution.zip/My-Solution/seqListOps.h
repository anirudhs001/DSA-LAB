#include "storage.h"

extern seqlist createlist();
extern void initialize_elements (joblist arr);
extern void insertelements (joblist arr,seqarr s);
extern void printseqlist(seqlist);
extern void copy_sorted_ele (seqarr , joblist);
extern void printjoblist(joblist j);
extern seqlist insert(Job j , seqlist sl);
