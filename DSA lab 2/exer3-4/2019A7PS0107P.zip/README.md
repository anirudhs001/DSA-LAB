Submission for lab2
ANIRUDH SINGH
2019A7PS0107P


driver_old.c is the modified version of driver.c we were given in the lab sheet.
It contains all the methods we were asked to implement(for simple linkedlist) and a few dummy method calls to test them.


driver.c is the new file(creating a stack ADT with linkedlist) we were asked to furnish in the lab sheet. 
It creates a linked list and calls the push and pop functions(declared and defined in Stack.h and Stack.c, respectively).    

I have also implemented the function printStack in Stack.c and Stack.h to be able to visualize the stack at any moment.
